package com.overlay.graph

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

class DrawView(ctx: Context) : View(ctx) {
    var calibrating = false
        set(v) { field = v; invalidate() }
    var onFit: ((Fit.Result?) -> Unit)? = null
    var onMoveBy: ((Int, Int) -> Unit)? = null
    var onResizeBy: ((Int, Int) -> Unit)? = null

    private val dens = resources.displayMetrics.density
    private val hs = 44f * dens
    private val pts = ArrayList<PointF>()
    private var result: Fit.Result? = null
    private var lastX = 0f
    private var lastY = 0f
    private var resizing = false

    private fun stroke(color: Long, w: Float): Paint {
        val p = Paint()
        p.color = color.toInt()
        p.strokeWidth = w
        p.style = Paint.Style.STROKE
        p.isAntiAlias = true
        return p
    }
    private val minor = stroke(0x6600C853L, 1f)
    private val major = stroke(0xAA00C853L, 2f)
    private val axis = stroke(0xFFFF00FFL, 3f)
    private val pen = stroke(0xFFFF0000L, 5f)
    private val fitPaint = stroke(0xFF0050FFL, 4f)
    private val fill = Paint().apply { color = 0x33FFFF00L.toInt(); style = Paint.Style.FILL }
    private val handle = Paint().apply { color = 0xCC0050FFL.toInt(); style = Paint.Style.FILL }
    private val txt = Paint().apply { color = 0xFF000000L.toInt(); textSize = 14f * dens; isAntiAlias = true }

    fun clear() {
        pts.clear()
        result = null
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (calibrating) c.drawRect(0f, 0f, w, h, fill)
        for (i in 0..50) {
            val x = i * w / 50f
            c.drawLine(x, 0f, x, h, if (i == 25) axis else if (i % 5 == 0) major else minor)
        }
        for (j in 0..30) {
            val y = j * h / 30f
            c.drawLine(0f, y, w, y, if (j == 15) axis else if (j % 5 == 0) major else minor)
        }
        val r = result
        if (r != null) {
            val path = Path()
            var down = false
            val steps = 500
            for (s in 0..steps) {
                val x = -25.0 + 50.0 * s / steps
                val y = r.eval(x)
                if (y.isNaN() || abs(y) > 60.0) { down = false; continue }
                val px = ((x + 25.0) / 50.0 * w).toFloat()
                val py = ((15.0 - y) / 30.0 * h).toFloat()
                if (!down) { path.moveTo(px, py); down = true } else path.lineTo(px, py)
            }
            c.drawPath(path, fitPaint)
        }
        for (i in 1 until pts.size) c.drawLine(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y, pen)
        if (calibrating) {
            c.drawRect(w - hs, h - hs, w, h, handle)
            c.drawText("Kéo để dời lưới | kéo ô xanh để đổi cỡ", 12f * dens, 24f * dens, txt)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (calibrating) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX
                    lastY = e.rawY
                    resizing = e.x > width - hs && e.y > height - hs
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - lastX).toInt()
                    val dy = (e.rawY - lastY).toInt()
                    if (dx != 0 || dy != 0) {
                        if (resizing) onResizeBy?.invoke(dx, dy) else onMoveBy?.invoke(dx, dy)
                        lastX += dx
                        lastY += dy
                    }
                }
            }
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pts.clear()
                result = null
                pts.add(PointF(e.x, e.y))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.historySize) pts.add(PointF(e.getHistoricalX(i), e.getHistoricalY(i)))
                pts.add(PointF(e.x, e.y))
            }
            MotionEvent.ACTION_UP -> {
                pts.add(PointF(e.x, e.y))
                compute()
            }
        }
        invalidate()
        return true
    }

    private fun compute() {
        val w = width.toDouble()
        val h = height.toDouble()
        val list = pts.map {
            Pair((it.x / w * 50.0 - 25.0).coerceIn(-25.0, 25.0), (15.0 - it.y / h * 30.0).coerceIn(-15.0, 15.0))
        }
        val r = Fit.fit(list)
        result = r
        onFit?.invoke(r)
        invalidate()
    }
}
