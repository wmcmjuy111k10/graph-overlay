package com.overlay.graph

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs

object Fit {
    const val DEG = 12

    // q: hệ số theo x (q[j] là hệ số x^j). m, c, h: dạng theo t=(x-c)/h dùng để vẽ xem trước.
    class Result(val q: DoubleArray, val m: DoubleArray, val c: Double, val h: Double) {
        fun eval(x: Double): Double {
            val t = (x - c) / h
            var s = m[DEG]
            for (j in DEG - 1 downTo 0) s = s * t + m[j]
            return s
        }
    }

    fun fit(raw: List<Pair<Double, Double>>): Result? {
        if (raw.size < 10) return null
        val s = raw.sortedBy { it.first }
        val x0 = s.first().first
        val x1 = s.last().first
        if (x1 - x0 < 2.0) return null
        val n = DEG + 1
        val samples = 300
        val c = (x0 + x1) / 2.0
        val h = (x1 - x0) / 2.0

        val a = Array(n) { DoubleArray(n + 1) }
        var k = 0
        for (i in 0 until samples) {
            val x = x0 + (x1 - x0) * i / (samples - 1)
            while (k < s.size - 2 && s[k + 1].first < x) k++
            val xa = s[k].first
            val ya = s[k].second
            val xb = s[k + 1].first
            val yb = s[k + 1].second
            val y = if (xb - xa < 1e-9) ya else ya + (yb - ya) * ((x - xa) / (xb - xa)).coerceIn(0.0, 1.0)
            val t = (x - c) / h
            val tt = DoubleArray(n)
            tt[0] = 1.0
            tt[1] = t
            for (j in 2 until n) tt[j] = 2 * t * tt[j - 1] - tt[j - 2]
            for (r in 0 until n) {
                for (cc in 0 until n) a[r][cc] += tt[r] * tt[cc]
                a[r][n] += tt[r] * y
            }
        }
        for (col in 0 until n) {
            var p = col
            for (r in col + 1 until n) if (abs(a[r][col]) > abs(a[p][col])) p = r
            val tmp = a[col]; a[col] = a[p]; a[p] = tmp
            if (abs(a[col][col]) < 1e-12) return null
            for (r in 0 until n) {
                if (r != col) {
                    val f = a[r][col] / a[col][col]
                    for (kk in col..n) a[r][kk] -= f * a[col][kk]
                }
            }
        }
        val b = DoubleArray(n) { a[it][n] / a[it][it] }

        // Chebyshev -> đơn thức theo t
        val pm = Array(n) { DoubleArray(n) }
        pm[0][0] = 1.0
        pm[1][1] = 1.0
        for (kk in 2 until n) for (j in 0 until n) {
            val sh = if (j > 0) pm[kk - 1][j - 1] else 0.0
            pm[kk][j] = 2 * sh - pm[kk - 2][j]
        }
        val m = DoubleArray(n)
        for (kk in 0 until n) for (j in 0 until n) m[j] += b[kk] * pm[kk][j]

        // thế t = (x - c)/h = al*x + be, bằng Horner trên đa thức
        val al = 1.0 / h
        val be = -c / h
        var q = DoubleArray(n)
        q[0] = m[DEG]
        var deg = 0
        for (j in DEG - 1 downTo 0) {
            val r = DoubleArray(n)
            for (i in 0..deg) {
                r[i] += q[i] * be
                r[i + 1] += q[i] * al
            }
            deg++
            r[0] += m[j]
            q = r
        }
        return Result(q, m, c, h)
    }

    // in số thập phân thường (không dùng 1e-10), giữ d chữ số có nghĩa
    private fun num(v: Double, d: Int): String {
        if (v == 0.0 || v.isNaN() || v.isInfinite()) return "0"
        return BigDecimal(v).round(MathContext(d)).stripTrailingZeros().toPlainString()
    }

    // Horner: chỉ cần + - * ( ) x
    fun toHorner(r: Result, d: Int): String {
        val c = r.q
        var s = num(c[DEG], d)
        for (j in DEG - 1 downTo 0) {
            val v = c[j]
            s = "(" + s + ")*x" + (if (v < 0) "-" else "+") + num(abs(v), d)
        }
        return s
    }

    // Khai triển: a0+a1*x+a2*x^2+...
    fun toExpanded(r: Result, d: Int): String {
        val sb = StringBuilder()
        for (j in 0..DEG) {
            val v = r.q[j]
            if (v < 0) sb.append("-") else if (j > 0) sb.append("+")
            sb.append(num(abs(v), d))
            if (j >= 1) sb.append("*x")
            if (j >= 2) sb.append("^").append(j)
        }
        return sb.toString()
    }
}
