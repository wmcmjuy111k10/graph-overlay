package com.overlay.graph

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(48, 48, 48, 48)

        val tv = TextView(this)
        tv.textSize = 15f
        tv.text = "1) Cấp quyền hiển thị trên ứng dụng khác.\n" +
            "2) Bấm Bật overlay, sẽ có nút tròn xanh nổi.\n" +
            "3) Mở game (xoay ngang), chạm nút tròn để mở lưới + menu.\n" +
            "4) Bấm Căn chỉnh, kéo lưới cho khớp lưới game (kéo ô xanh góc dưới phải để đổi cỡ), bấm Xong.\n" +
            "5) Vẽ 1 nét, bấm Copy, chạm nút tròn để đóng rồi dán vào game."
        col.addView(tv)

        val b1 = Button(this)
        b1.text = "1. Cấp quyền overlay"
        b1.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        col.addView(b1)

        val b2 = Button(this)
        b2.text = "2. Bật overlay"
        b2.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Chưa cấp quyền overlay", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        col.addView(b2)

        val b3 = Button(this)
        b3.text = "Tắt overlay"
        b3.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }
        col.addView(b3)

        setContentView(col)
    }
}
