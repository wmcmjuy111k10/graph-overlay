package com.overlay.graph

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var bubble: TextView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var dv: DrawView? = null
    private var bar: LinearLayout? = null
    private var info: TextView? = null
    private var calibrating = false
    private var useHorner = true
    private var digits = 17
    private var fit: Fit.Result? = null
    private var text = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ov")
            .setContentTitle("Graph Overlay đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        startForeground(1, n)
        addBubble()
    }

    override fun onDestroy() {
        closeMenu()
        try { wm.removeView(bubble) } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addBubble() {
        val tv = TextView(this)
        tv.text = "~"
        tv.textSize = 22f
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xDD2E7D32L.toInt())
        tv.background = bg
        val size = dp(46)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("bx", dp(4))
        lp.y = prefs.getInt("by", dp(120))
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("bx", lp.x).putInt("by", lp.y).apply()
                    } else {
                        Handler(Looper.getMainLooper()).post { toggleMenu() }
                    }
                }
            }
            true
        }
        bubble = tv
        bubbleLp = lp
        wm.addView(tv, lp)
    }

    private fun toggleMenu() {
        if (dv == null) openMenu() else closeMenu()
    }

    private fun saveRect(lp: WindowManager.LayoutParams) {
        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).putInt("w", lp.width).putInt("h", lp.height).apply()
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun refreshText() {
        val r = fit
        if (r == null) {
            text = ""
            info?.text = "Vẽ 1 nét trên lưới rồi thả tay"
            return
        }
        text = if (useHorner) Fit.toHorner(r, digits) else Fit.toExpanded(r, digits)
        info?.text = "[" + text.length + " ký tự] " + text
    }

    private fun copy() {
        if (text.isEmpty()) {
            toast("Chưa có phương trình")
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("eq", text))
        toast("Đã copy " + text.length + " ký tự")
    }

    private fun openMenu() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        calibrating = false

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        val lp = WindowManager.LayoutParams(
            prefs.getInt("w", (sw * 0.625).toInt()),
            prefs.getInt("h", (sh * 0.81).toInt()),
            overlayType(), flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("x", (sw * 0.194).toInt())
        lp.y = prefs.getInt("y", (sh * 0.035).toInt())

        val v = DrawView(this)
        v.onFit = { r ->
            fit = r
            refreshText()
        }
        v.onMoveBy = { dx, dy ->
            lp.x += dx
            lp.y += dy
            wm.updateViewLayout(v, lp)
            saveRect(lp)
        }
        v.onResizeBy = { dx, dy ->
            lp.width = maxOf(dp(150), lp.width + dx)
            lp.height = maxOf(dp(90), lp.height + dy)
            wm.updateViewLayout(v, lp)
            saveRect(lp)
        }
        wm.addView(v, lp)
        dv = v

        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.setBackgroundColor(0xE6212121L.toInt())
        b.setPadding(dp(6), dp(4), dp(6), dp(4))
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        info = t
        b.addView(t)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        b.addView(row)

        fun btn(label: String, onClick: (Button) -> Unit): Button {
            val x = Button(this)
            x.text = label
            x.isAllCaps = false
            x.textSize = 12f
            x.setTextColor(Color.WHITE)
            x.setBackgroundColor(0xFF2E7D32L.toInt())
            x.minWidth = 0
            x.minHeight = 0
            x.minimumWidth = 0
            x.minimumHeight = 0
            x.setPadding(dp(4), dp(8), dp(4), dp(8))
            x.setOnClickListener { onClick(x) }
            val l = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            l.setMargins(dp(2), dp(4), dp(2), 0)
            row.addView(x, l)
            return x
        }

        btn("Xoá") {
            v.clear()
            fit = null
            refreshText()
        }
        btn("Copy") { copy() }
        btn(if (useHorner) "Horner" else "Khai triển") {
            useHorner = !useHorner
            it.text = if (useHorner) "Horner" else "Khai triển"
            refreshText()
        }
        btn(digits.toString() + " số") {
            digits = when (digits) {
                17 -> 12
                12 -> 8
                else -> 17
            }
            it.text = digits.toString() + " số"
            refreshText()
        }
        btn("Căn chỉnh") {
            calibrating = !calibrating
            v.calibrating = calibrating
            it.text = if (calibrating) "Xong" else "Căn chỉnh"
        }
        btn("Đóng") { closeMenu() }

        val bl = WindowManager.LayoutParams(
            (sw * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), flags, PixelFormat.TRANSLUCENT
        )
        bl.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        wm.addView(b, bl)
        bar = b
        refreshText()

        // đưa nút tròn lên trên cùng để luôn bấm được
        try { wm.removeView(bubble) } catch (e: Exception) { }
        wm.addView(bubble, bubbleLp)
    }

    private fun closeMenu() {
        try { dv?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { bar?.let { wm.removeView(it) } } catch (e: Exception) { }
        dv = null
        bar = null
        info = null
        calibrating = false
    }
}
